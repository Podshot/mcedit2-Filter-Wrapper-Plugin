class OptionsWrapper:
    
    def __init__(self):
        self._options = {}
        
    def setValue(self, key, value):
        print "Changed Value (" + key + ": " + str(value)
        self._options[key] = value
        