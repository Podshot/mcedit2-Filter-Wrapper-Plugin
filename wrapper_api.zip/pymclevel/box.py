import mceditlib.selection as Selection

BoundingBox = Selection.BoundingBox
FloatBox = Selection.FloatBox
